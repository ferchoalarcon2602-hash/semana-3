
# Create your views here.
from django.shortcuts import render
from .models import aprendiz

def listar(request):
    aprendices = aprendiz.objects.all()
    contexto = {
        'aprendices' : aprendices
    }

    return render(request, 'clases/index.html', contexto)
